import React from 'react'

const ScreenAuth = () => {
  return (
    <div>ScreenAuth</div>
  )
}

export default ScreenAuth