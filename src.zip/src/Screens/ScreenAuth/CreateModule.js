import React from 'react'
import AdminSidebar from '../../Components/AdminSidebar'
import NavHeader from '../../Components/NavHeader'

function CreateModule() {
  return (
    <div>
    <NavHeader/>
    <AdminSidebar/>
    </div>
  )
}

export default CreateModule