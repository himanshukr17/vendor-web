import React from 'react'

function CreateScreen() {
  return (
    <div>CreateScreen</div>
  )
}

export default CreateScreen