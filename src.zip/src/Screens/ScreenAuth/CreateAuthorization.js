import React from 'react'

function CreateAuthorization() {
  return (
    <div>CreateAuthorization</div>
  )
}

export default CreateAuthorization