import React from 'react'

function CreateRole() {
  return (
    <div>CreateRole</div>
  )
}

export default CreateRole