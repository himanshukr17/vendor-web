import React from 'react'

function AssignRole() {
  return (
    <div>AssignRole</div>
  )
}

export default AssignRole